﻿configuration web1
{
    node localhost
    {
        WindowsFeature WebServer
        {
            Name = 'Web-Server'
            Ensure = 'Present'
        }

        WindowsFeature WebMgmtTools
        {
            Name = 'Web-Mgmt-Tools'
            Ensure = 'Present'
        }
    }
}